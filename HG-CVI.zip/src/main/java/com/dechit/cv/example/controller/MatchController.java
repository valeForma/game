package com.dechit.cv.example.controller;

import com.dechit.cv.example.service.MatchService;
import org.springframework.stereotype.Controller;

@Controller
public class MatchController {

    private MatchService matchService;

    public void setMatchService(MatchService matchService) {
        this.matchService = matchService;
    }



}
