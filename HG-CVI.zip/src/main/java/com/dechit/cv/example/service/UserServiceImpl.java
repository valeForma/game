package com.dechit.cv.example.service;

import com.dechit.cv.example.operationDAO.OperationDao;
import com.dechit.cv.example.user.Utente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("userService")
public class UserServiceImpl implements UserService {
    @Autowired
    private OperationDao<Utente> operationDao;

    public void setOperationDao(OperationDao<Utente> operationDao){
        this.operationDao = operationDao;
    }

    @Override
    @Transactional
    public void addPerson(Utente u) {
        this.operationDao.add(u);
    }

    @Override
    @Transactional
    public void updatePerson(Utente u) {
        this.operationDao.updtate(u);
    }

    @Override
    @Transactional
    public List<Utente> listPersons() {
        return this.operationDao.list();
    }

    @Override
    @Transactional
    public Utente getPersonById(String nickname) {
        return this.getPersonById(nickname);
    }
}
