package com.dechit.cv.example.operationDAO;

import java.util.List;

public interface OperationDao<T> {
//operazioni di hibernate
    void add(T t);
    void updtate(T t);
    List<T> list();
    T getT(String nickname);

}
