package com.dechit.cv.example.controller;

import com.dechit.cv.example.service.UserService;
import com.dechit.cv.example.exception.ValidationFields;
import com.dechit.cv.example.user.Utente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class UserController {

    //inserisci il display method
    //inserisci il @RequestParam o utilizza la @ModelAttribute per mappare i parametri dall'html


    //è possibile inserire delle validazioni tipo @Valid, @Size ecc.
    //BindingResult vengono caricati tutti gli errori, dove è possibile anche caricarli custom(data da una hashMap<NomeAtt,errore>)
    //Bindig ha bisogno di un path di posizione dato dalla @RequestMapping

    // TODO inserisci controlli lato server!!

    private UserService userService;

    @Autowired(required = true)
    @Qualifier(value="userService")
    public void setUserService(UserService us) {
        this.userService = us;
    }

    //qui nella jsp qui andrò ad utilizzare ${nome campi}


    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public String listUser(Model model) {
        //oggetto che si occupa di passare i dati dalla model alla view
        model.addAttribute("users", new Utente());
        model.addAttribute("listUsers", this.userService.listPersons());
        return "users";
    }

    //todo utilizzare Costraint(validateby=nome.class) implements ConstraintValidator<T,T>
    @RequestMapping(value = "/users", method = RequestMethod.POST)
    public String addUsers(@Validated(ValidationFields.class) @ModelAttribute("users") Utente utente) {
        if (utente.getId() == 0) {
            //TODO aggiungere controlli esistenza
            //TODO aggiungere controllo password con regex
            //TODO aggiungere controllo CF

            this.userService.addPerson(utente);
        } else {
            this.userService.updatePerson(utente);
        }
        return "redirect:/users";
    }


    @RequestMapping(value = "/users/edit/{nickname}")
    public String editUsers(@PathVariable("nickname") String nickname, Model model) {
        model.addAttribute("users", this.userService.getPersonById(nickname));
        model.addAttribute("listUsers", this.userService.listPersons());
        return "users";
    }

}
/*
*  non è possibile staccare le jsp dall'html
*  la massimo è possibile generare un json o un js da elaborare
*
*  non è possibile utilizzare lo stesso principio di React, ovvero la SPA
* */