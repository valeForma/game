package com.dechit.cv.example.service;

import com.dechit.cv.example.user.Utente;

import java.util.List;

public interface UserService {
    public void addPerson(Utente u);
    public void updatePerson(Utente u);
    public List<Utente> listPersons();
    public Utente getPersonById(String nickname);
}
