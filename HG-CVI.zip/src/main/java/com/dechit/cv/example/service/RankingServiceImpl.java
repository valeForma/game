package com.dechit.cv.example.service;

import com.dechit.cv.example.operationDAO.OperationDao;
import com.dechit.cv.example.games.ClassificaGenerale;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RankingServiceImpl implements RankingService {

private OperationDao<ClassificaGenerale> operationDao;

    public void setcGoDao(OperationDao<ClassificaGenerale> operationDao) {
        this.operationDao = operationDao;
    }
    @Override
    @Transactional

    public List<ClassificaGenerale> showByNation(String nation) {
        return (List<ClassificaGenerale>) this.operationDao.getT(nation);
    }

    @Override
    @Transactional
    public List<ClassificaGenerale> show() {
        return this.operationDao.list();
    }

    @Override
    @Transactional
    public void addRanked(ClassificaGenerale classificaGenerale) {
        this.operationDao.add(classificaGenerale);
    }

    public void setOperationDao(OperationDao operationDao) {
        this.operationDao = operationDao;
    }
}
