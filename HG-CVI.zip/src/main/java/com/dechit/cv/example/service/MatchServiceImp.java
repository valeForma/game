package com.dechit.cv.example.service;

import com.dechit.cv.example.operationDAO.OperationDao;
import com.dechit.cv.example.match.Partita;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class MatchServiceImp implements MatchService {

    private OperationDao<Partita> operationDao;

    public void setOperationDao(OperationDao<Partita> operationDao){
        this.operationDao = operationDao;
    }


    @Override
    @Transactional
    public void addMatch(Partita p) {
    this.operationDao.add(p);
    }

    @Override
    @Transactional
    public List<Partita> search(Partita p) {
        return this.operationDao.list();
    }

    @Override
    @Transactional
    //TODO devo fixarlo
    public List<Partita> show() {
        String p = String.valueOf('*');
        return (List<Partita>) this.operationDao.getT(p);
    }
}
