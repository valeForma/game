package com.dechit.cv.example.service;

import com.dechit.cv.example.games.ClassificaGenerale;

import java.util.List;

public interface RankingService {
    //estrai per nazione
    public List<ClassificaGenerale> showByNation(String nation);
    //prendi tutto
    public List<ClassificaGenerale> show();
    //add
    public void addRanked(ClassificaGenerale classificaGenerale);
}
