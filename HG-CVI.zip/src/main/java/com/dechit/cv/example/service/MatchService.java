package com.dechit.cv.example.service;

import com.dechit.cv.example.match.Partita;

import java.util.List;

public interface MatchService {

    public void addMatch(Partita p);
    public List<Partita> search(Partita p);
    public List<Partita> show();

}
