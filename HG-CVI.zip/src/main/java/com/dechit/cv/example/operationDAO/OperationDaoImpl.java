package com.dechit.cv.example.operationDAO;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class OperationDaoImpl<T> implements OperationDao {
    //semplice console.log
    private static final Logger logger = LoggerFactory.getLogger(OperationDaoImpl.class);

    private Class<T> genericType = (Class<T>)((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];

    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory = sf;
    }


    @Override
    public void add(Object t) {
        Session session = this.sessionFactory.getCurrentSession();
        session.persist(t);
        logger.info("messaggio di salvataggio");
    }

    @Override
    public void updtate(Object t) {
        Session session = this.sessionFactory.getCurrentSession();
        session.update(t);
        logger.info("messaggio di aggiornamento");
    }

    @Override
    public List<T> list() {
        Session session = this.sessionFactory.getCurrentSession();
        List<T> tList = session.createQuery("from " + this.genericType.getSimpleName()).list();
        for (T t : tList) {
            logger.info("messaggio" + t);
        }
        return tList;
    }

    @Override
    public Object getT(String nickname) {
//TODO vedi se funge sto metodo xD
        Session session = this.sessionFactory.getCurrentSession();
        T t = (T) session.load(this.genericType.getClass(), new String(nickname));
        logger.info("messaggio di carica" + t);
        return t;
    }


}
